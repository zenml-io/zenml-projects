from typing import Dict
from transformers import (
    TrainerCallback,
    TrainingArguments,
    TrainerState,
    TrainerControl,
)
from zenml import get_step_context


class ZenMLCallback(TrainerCallback):
    def on_evaluate(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        metrics: Dict[str, float],
        **kwargs
    ):
        try:
            context = get_step_context()
            context.model.log_metadata(
                {
                    f"step_{state.global_step}_eval_metrics": metrics,
                }
            )
        except RuntimeError:
            # If we can't get the context, silently pass
            return

    def on_save(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs
    ):
        # TODO: add ability to save model checkpoints here, will likely get redundant with Mounts
        pass
