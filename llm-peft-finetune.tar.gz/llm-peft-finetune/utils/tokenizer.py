from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from transformers import AutoTokenizer

def load_tokenizer(base_model_id: str, is_eval: bool = False) -> "AutoTokenizer":
    from transformers import AutoTokenizer

    if is_eval:
        tokenizer = AutoTokenizer.from_pretrained(
            base_model_id, add_bos_token=True, device_map="auto"
        )
    else:
        tokenizer = AutoTokenizer.from_pretrained(
            base_model_id,
            model_max_length=512,
            padding_side="left",
            add_eos_token=True,
            device_map="auto",
        )

        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def tokenize(prompt: str, tokenizer: "AutoTokenizer") -> dict:
    result = tokenizer(
        prompt,
        truncation=True,
        max_length=512,
        padding="max_length",
    )
    result["labels"] = result["input_ids"].copy()
    return result


def generate_and_tokenize_prompt(
    data_point: dict, tokenizer: "AutoTokenizer", system_prompt: str
):
    full_prompt = f"""{system_prompt}

### Target sentence:
{data_point["target"]}

### Meaning representation:
{data_point["meaning_representation"]}
"""
    return tokenize(full_prompt, tokenizer)

def tokenize_for_eval(data_point: dict, tokenizer: "AutoTokenizer", system_prompt: str):
    eval_prompt = f"""{system_prompt}

### Target sentence:
{data_point["target"]}

### Meaning representation:
"""
    return tokenizer(eval_prompt, return_tensors="pt").to("cuda")