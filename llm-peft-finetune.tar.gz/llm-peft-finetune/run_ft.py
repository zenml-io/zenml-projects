from pipelines.train import train
from zenml import logging as zenml_logging
zenml_logging.STEP_LOGS_STORAGE_MAX_MESSAGES = (
    10000  # workaround for https://github.com/zenml-io/zenml/issues/2252
)

if __name__ == "__main__":
    train.with_options(config_path="configs/default_finetune.yaml")()