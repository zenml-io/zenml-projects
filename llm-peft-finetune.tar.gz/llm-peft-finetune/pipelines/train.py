from zenml import pipeline, get_pipeline_context
from steps.finetune import configure, finetune, evaluate_and_promote
from steps.prepare_datasets import prepare_data
from zenml.config import DockerSettings
from zenml.client import Client
from zenml import logging as zenml_logging

zenml_logging.STEP_LOGS_STORAGE_MAX_MESSAGES = (
    10000  # workaround for https://github.com/zenml-io/zenml/issues/2252
)


@pipeline(
    settings={
        "docker": DockerSettings(
            parent_image="pytorch/pytorch:2.2.2-cuda11.8-cudnn8-runtime",
            requirements="requirements.txt",
        )
    }
)
def train():
    system_prompt, base_model_id = configure()
    datasets_dir = prepare_data(base_model_id=base_model_id, system_prompt=system_prompt)
    ft_model_dir = finetune(
        base_model_id,
        datasets_dir,
    )
    evaluate_and_promote(base_model_id, system_prompt, datasets_dir, ft_model_dir)
