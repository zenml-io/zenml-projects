from functools import partial
import torch
from zenml import get_step_context, step
from typing_extensions import Annotated
from typing import Tuple
from zenml.logger import get_logger
from zenml import logging as zenml_logging
from utils.callbacks import ZenMLCallback
from defaults import DEFAULT_BASE_MODEL_ID, DEFAULT_SYSTEM_PROMPT
from materializers.directory_materializer import DirectoryMaterializer
from zenml.materializers import BuiltInMaterializer
from pathlib import Path
from utils.loaders import load_base_model, load_tokenizer
from utils.tokenizer import tokenize_for_eval
import transformers
from datasets import load_from_disk
from peft import PeftModel

logger = get_logger(__name__)
zenml_logging.STEP_LOGS_STORAGE_MAX_MESSAGES = (
    10000  # workaround for https://github.com/zenml-io/zenml/issues/2252
)


@step
def configure(
    system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    base_model_id: str = DEFAULT_BASE_MODEL_ID,
) -> Tuple[Annotated[str, "system_prompt"], Annotated[str, "base_model_id"]]:
    return system_prompt, base_model_id


@step(output_materializers=[DirectoryMaterializer, BuiltInMaterializer])
def finetune(
    base_model_id: str,
    dataset_dir: Path,
    max_steps: int = 1000,
    logging_steps: int = 50,
    eval_steps: int = 50,
    save_steps: int = 50,
    optimizer: str = "paged_adamw_8bit",
    lr: float = 2.5e-5,
    per_device_train_batch_size: int = 2,
    gradient_accumulation_steps: int = 4,
    warmup_steps: int = 5,
) -> Annotated[Path, "ft_model_dir"]:

    project = "zenml-finetune"
    base_model_name = "mistral"
    run_name = base_model_name + "-" + project
    output_dir = "./" + run_name

    logger.info("Loading datasets...")
    tokenizer = load_tokenizer(base_model_id)
    tokenized_train_dataset = load_from_disk(dataset_dir / "train")
    tokenized_val_dataset = load_from_disk(dataset_dir / "val")

    logger.info("Loading base model...")
    model = load_base_model(base_model_id)

    trainer = transformers.Trainer(
        model=model,
        train_dataset=tokenized_train_dataset,
        eval_dataset=tokenized_val_dataset,
        args=transformers.TrainingArguments(
            output_dir=output_dir,
            warmup_steps=warmup_steps,
            per_device_train_batch_size=per_device_train_batch_size,
            gradient_checkpointing=True,
            gradient_accumulation_steps=gradient_accumulation_steps,
            max_steps=max_steps,
            learning_rate=lr,
            logging_steps=logging_steps,
            bf16=True,
            optim=optimizer,
            logging_dir="./logs",
            save_strategy="steps",
            save_steps=save_steps,
            evaluation_strategy="steps",
            eval_steps=eval_steps,
            do_eval=True,
        ),
        data_collator=transformers.DataCollatorForLanguageModeling(
            tokenizer, mlm=False
        ),
        callbacks=[ZenMLCallback()],
    )

    model.config.use_cache = (
        False  # silence the warnings. Please re-enable for inference!
    )

    logger.info("Training model...")
    trainer.train()

    logger.info("Saving model...")
    model.config.use_cache = True
    ft_model_dir = Path("model_dir")
    ft_model_dir.mkdir(parents=True, exist_ok=True)
    trainer.save_model(ft_model_dir)

    return ft_model_dir


@step
def evaluate_and_promote(
    base_model_id: str, system_prompt: str, datasets_dir: Path, ft_model_dir: Path
) -> None:
    logger.info("Evaluating model...")

    tokenizer = load_tokenizer(base_model_id, is_eval=True)
    tokenize = partial(
        tokenize_for_eval, tokenizer=tokenizer, system_prompt=system_prompt
    )
    test_dataset = load_from_disk(datasets_dir / "test_raw")
    tokenized_train_dataset = test_dataset.map(tokenize)

    base_model = load_base_model(base_model_id)
    base_model.eval()
    ft_model = PeftModel.from_pretrained(base_model, ft_model_dir)
    ft_model.eval()

    base_predictions = []
    ft_predictions = []
    ground_truths = []
    with torch.no_grad():
        base_model.generate(
            **tokenized_train_dataset, max_new_tokens=100, pad_token_id=2
        )
        base_predictions = tokenizer.batch_decode(
            
        )
        for data_point in test_dataset:
            model_input = tokenize_for_eval(data_point, tokenizer, system_prompt)
            ground_truths.append(data_point["meaning_representation"])

            base_predictions.append(
                tokenizer.decode(
                    base_model.generate(
                        **model_input, max_new_tokens=100, pad_token_id=2
                    )[0],
                    skip_special_tokens=True,
                )
            )

            ft_predictions.append(
                tokenizer.decode(
                    ft_model.generate(
                        **model_input, max_new_tokens=100, pad_token_id=2
                    )[0],
                    skip_special_tokens=True,
                )
            )

            logger.info(f"Base model prediction: {base_predictions[-1]}")
            logger.info(f"FT model prediction: {ft_predictions[-1]}")
            logger.info(f"Ground truth: {ground_truths[-1]}")

    promotion_decision = True

    if promotion_decision:
        get_step_context().model.set_stage("staging", True)
